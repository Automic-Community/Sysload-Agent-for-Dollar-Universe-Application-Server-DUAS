#!/bin/bash
# CollectDuas.sh
# v1.0
# Collect metrics on Dollar Universe Application Server
# by CHM for Automic
# on 14/03/2016
# Copyright Automic Software

###############################################################################
# Init
shopt -s extglob
scriptpath=$0
currdir=`dirname $scriptpath`
cd $currdir
currdir=$(pwd)
currscript=`basename $scriptpath`
fLog=${currdir}/collectduas.log

###############################################################################
#==============================================================================
# FUNCTIONS
#==============================================================================
logdebug()
{
	if [ "$DEBUG" != "ON" ]; then
		return 0
	fi
	echo "${now} ${server} ${currscript}: $*" | tee -a $fLog
}

log()
{
	now=`date +"%d/%m/%Y %H:%M:%S"`
	echo "${now} ${server} ${currscript}: $*" >> $fLog
}

#==============================================================================
# Write collected metric to standard output
print_metric() 
{
	metric=$1
	value=$2
	instance=$3
	echo "${metric}#${instance}##${value}"
}

###############################################################################
get_pstree()
{
	if [ "$1" == "0" ] || [ "$1" == "" ]; then
		pslist=""
		return
	fi
	
	if [ "${OS}" == "Linux" ]; then
		pslist=( `pstree -n -A -a -p $1 |cut -d, -f2|cut -f1 -d' '|tail ${TAILARG} +2` )
	else
		if [ "${OS}" == "SunOS" ] || [ "${OS}" == "HP-UX" ]; then
			pslist=( `ptree $1 |awk '{print $1}'|tail ${TAILARG} +2` )
		elif [ "${OS}" == "AIX" ]; then
			pslist=( `ps -T $1 |awk '{print $1}'|tail ${TAILARG} +2` )
		else
			log "Operating system not supported : ${OS}"
			exit 10
		fi
	fi
}

get_pid()
{
	case $1 in
		ioV6 | uxioserv_V6) process="uxioserv_V6";;
		dqmV6 | uxdqmsrv_V6 ) process="uxdqmsrv_V6";;
		io | uxioserv) process="uxioserv";;
		dqm | uxdqmsrv ) process="uxdqmsrv";;
		cdj | uxcdjsrv ) process="uxcdjsrv";;
		bvs | uxbvssrv ) process="uxbvssrv";;
		eep | uxeepsrv ) process="uxeepsrv start";;
		cal | uxcal ) process="uxcal";;
		ord | uxord ) process="uxord";;
		ech | uxech ) process="uxech";;
		sur | uxsur ) process="uxsur";;
		sap | uxagtsap ) process="uxagtsap";;
		**) return 0;;
	esac
	area=`echo $2|tr '[:lower:]' '[:upper:]'`
	soc=$3
	logdebug "Searching process $process $soc $area $S_NODENAME"
	pid=`ps ${PSARG} -e -o pid,args|grep "$process $soc $area $S_NODENAME"|grep -v grep|awk '{print $1}'`
	if [ "$pid" == "" ]; then
		pid=0
	fi
	logdebug "[get_pid] PID of $process $COMPANY_NAME $area $S_NODENAME=$pid"
	if [ "$1" == "IO" ] && [ "$area" == "X" ] && [ $pid -eq 0 ]; then
		DUAS_STATUS="OFF"
		logdebug "IO/X not found, DUAS status=$DUAS_STATUS"
	fi
}

diff_times()
{
	start_time=$1
	end_time=$2

	H1=`echo ${start_time} | cut -f1 -d:`
	M1=`echo ${start_time} | cut -f2 -d:`
	S1=`echo ${start_time} | cut -f3 -d:`
	H2=`echo ${end_time} | cut -f1 -d:`
	M2=`echo ${end_time} | cut -f2 -d:`
	S2=`echo ${end_time} | cut -f3 -d:`
    H1=${H1##0}
    M1=${M1##0}
    S1=${S1##0}
    H2=${H2##0}
    M2=${M2##0}
    S2=${S2##0}
	let hms1=H1*3600+M1*60+S1
	let hms2=H2*3600+M2*60+S2
	if [ $hms1 -gt $hms2 ]; then
		let hms2=hms2+86400
	fi
	let diff=hms2-hms1
}

get_timestamp()
{
	to_search="$1"
	timestamp=`grep "$to_search" $UNI_DIR_LOG/universe*.log | grep $today | awk '{print $3}' | grep 'X'`
}

get_resptime()
{
	dbfile=$1
    curr_node=$2
	get_timestamp "$dbfile reorganization successful"
	diff_times $t0 $timestamp
    print_metric "DB_REORG_RESPTIME_SECS" $diff ${curr_node}_$dbfile
	t0=$timestamp
}

get_purgereorg()
{
    curr_node=$1
    today=`date +%Y-%m-%d`

    # For a V6 node - pattern to search for : 
    # ##### START OF IO PURGE #####
    # ##### END OF IO PURGE #####
    get_timestamp "##### START OF IO PURGE #####"
    purt0=$timestamp
    if [ "$purt0" == "" ] || [ $purt0 -le 0 ]; then
        # Considering this is a V5 node : 
        get_timestamp "online purge start"
        purt0=$timestamp
        get_timestamp "online purge end"
        purt1=$timestamp
    else
        # This is a V6 node : 
        get_timestamp "##### END OF IO PURGE #####"
        purt1=$timestamp
    fi

    diff_times $purt0 $purt1
    print_metric "PURGE_RESPTIME_SECS" $diff $curr_node

    reorgt0=$purt1
    get_timestamp "End of reorg for area X"
    reorgt1=$timestamp
    if [ "$reorgt1" = "" ]; then
        reorgt0=""
    fi
    diff_times $reorgt0 $reorgt1
    print_metric "REORG_RESPTIME_SECS" $diff $curr_node

    t0=$reorgt0
    get_resptime u_fecd60 $curr_node
    get_resptime u_fecl60 $curr_node
    get_resptime u_fmca60 $curr_node
    get_resptime u_fmcm60 $curr_node
    get_resptime u_fmcx60 $curr_node
    get_resptime u_fmer60 $curr_node
    get_resptime u_fmev60 $curr_node
    get_resptime u_fmfu60 $curr_node
    get_resptime u_fmhs60 $curr_node
    get_resptime u_fmlc60 $curr_node
    get_resptime u_fmlp60 $curr_node
    get_resptime u_fmpf60 $curr_node
    get_resptime u_fmph60 $curr_node
    get_resptime u_fmpi60 $curr_node
    get_resptime u_fmpl60 $curr_node
    get_resptime u_fmsb60 $curr_node
    get_resptime u_fmse60 $curr_node
    get_resptime u_fmsp60 $curr_node
    get_resptime u_fmta60 $curr_node
    get_resptime u_fmtp60 $curr_node
    get_resptime u_fmtr60 $curr_node
    get_resptime u_fppf60 $curr_node
    get_resptime u_frup60 $curr_node
    get_resptime u_fseu60 $curr_node
    get_resptime u_fupr60 $curr_node
    get_resptime u_fbvi60 $curr_node
    get_resptime u_fbvm60 $curr_node
    get_resptime u_frrv60 $curr_node
    get_resptime u_fmat60 $curr_node
    get_resptime u_fmhr60 $curr_node
    get_resptime u_fmoe60 $curr_node
    get_resptime u_fmrn60 $curr_node
    get_resptime dffdob60 $curr_node
    get_resptime u_fmeq60 $curr_node
    get_resptime u_fmqp60 $curr_node
    get_resptime u_fmqr60 $curr_node
    get_resptime u_fmrl60 $curr_node
}

count_obj()
{
	obj=$1
	arg=${2:-""}
    curr_node=$3
	logdebug "$obj ... "
	if [ ${DO_COLLECT} -gt 0 ]; then
		if [ "$arg" != "" ]; then
			nb=`$UNI_DIR_EXEC/uxlst $obj $arg | wc -l`
		else
			nb=`$UNI_DIR_EXEC/uxlst $obj | wc -l`
		fi
		let nb=nb-4
	else
		nb=-1
	fi
	logdebug "$nb"
    print_metric "OBJECTS" $nb ${curr_node}_$obj
	if [ $nb -lt 0 ]; then
		nb=0
	fi
	let total=total+nb
}

get_objects()
{
    DO_COLLECT=$1
    curr_node=$2
    total=0
    count_obj res "" $curr_node
    count_obj class "" $curr_node
    count_obj dom "" $curr_node
    count_obj appl "" $curr_node
    count_obj rul "" $curr_node
    count_obj upr "" $curr_node
    count_obj ses "" $curr_node
    count_obj tsk "" $curr_node
    count_obj trig "" $curr_node
    count_obj book "" $curr_node
    count_obj note "" $curr_node
    count_obj node "" $curr_node
    count_obj user "" $curr_node
    count_obj mu "" $curr_node
    count_obj mut "" $curr_node
    count_obj cal "" $curr_node
    if [ ${DO_COLLECT} -gt 0 ]; then
        if [ -f $UNI_DIR_EXEC/uxlstque ]; then
            nb=`$UNI_DIR_EXEC/uxlstque | wc -l`
            let nb=nb-4
        else
            nb=-1
        fi
    else
        nb=-1
    fi
    print_metric "OBJECTS" $nb "${curr_node}_queue"

    let total=total+nb
    if [ $total -lt 0 ]; then
        total=-1
    fi
    print_metric "ALL_DESIGN_OBJECTS" $total ${curr_node}

    if [ -f /tmp/du6since_${curr_node} ]; then
        now=`cat /tmp/du6since_${curr_node}`
    else
        now="00/00/0000,0000"
        #now=`date +%m/%d/%Y,%H%M`
    fi	

    count_obj fla "" $curr_node
    count_obj ctl "since=($now) status=O,R,T,A" $curr_node
    count_obj hcx "since=($now)" $curr_node
    if [ ${DO_COLLECT} ]; then
        date +%m/%d/%Y,%H%M > /tmp/du6since_${curr_node}
    fi
    count_obj evt "" $curr_node
    count_obj sta "" $curr_node
    count_obj oex "" $curr_node
    count_obj out "" $curr_node

    #today=`date +"%Y%m%d"`
    #currhour=`date +"%H"`
    #if [ ! -f /tmp/du6countctlhst_$today ] && [ $currhour -ge 1 ]; then
    #	rm -f /tmp/du6countctlhst_*
    #	touch /tmp/du6countctlhst_$today
    #	count_obj "hcx"
    #fi
    if [ $total -lt 0 ]; then
        total=-1
    fi

    print_metric "ALL_OBJECTS" moy $total ${curr_node}
}

get_size()
{
	dbfile=$1
	datadir=$2
    curr_node=$3
	extension=${4:-""}
	logdebug "$dbfile ... (node=$curr_node)"
	total=0
	for size in `ls -l $datadir/${dbfile}*|awk '{print $5}'`
	do
		let total=total+size
	done
	#let total=total/(1024*1024)
	total=`echo "scale=3;$total/(1024*1024)"|bc`
	#echo $total
	logdebug "$total MB"
    print_metric "SIZE_MB" $total ${curr_node}_${dbfile}${extension}
	file_size=$total
	return 0
}

get_datasize()
{
    curr_node=$1
    logdebug "get_datasize $curr_node"
    total=0
    if [ -d $UNI_DIR_ROOT/data/exp ]; then
        UXDEX=$UNI_DIR_ROOT/data/exp
    else
        UXDEX=$UNI_DIR_ROOT/exp/data
    fi
    dbtotal=0
    for dta in `ls -1 $UXDEX/u_*.dta`
    do
        dbfile=`basename $dta`
        dbfile=${dbfile/\.*/}
        get_size $dbfile $UXDEX $curr_node ""
        dbtotal=`echo "scale=3;$dbtotal+$file_size"|bc`
    done
    for dta in `ls -1 $UXDEX/*.db`
    do
        dbfile=`basename $dta`
        dbfile=${dbfile/\.*/}
        get_size ${dbfile} $UXDEX $curr_node "_EXP"
        dbtotal=`echo "scale=3;$dbtotal+$file_size"|bc`
    done

    if [ -d $UNI_DIR_ROOT/data ]; then
        UNI_DIR_DATA=$UNI_DIR_ROOT/data
    else
        UNI_DIR_DATA=$UNI_DIR_ROOT
    fi
    for dta in `ls -1 $UNI_DIR_DATA/u_*.dta`
    do
        dbfile=`basename $dta`
        dbfile=${dbfile/\.*/}
        get_size $dbfile $UNI_DIR_DATA $curr_node ""
        dbtotal=`echo "scale=3;$dbtotal+$file_size"|bc`
    done
    for dta in `ls -1 $UNI_DIR_DATA/*.db`
    do
        dbfile=`basename $dta`
        dbfile=${dbfile/\.*/}
        get_size $dbfile $UNI_DIR_DATA $curr_node ""
        dbtotal=`echo "scale=3;$dbtotal+$file_size"|bc`
    done
    for dta in `ls -1 $UNI_DIR_DATA/data_sap/u*.dta`
    do
        dbfile=`basename $dta`
        dbfile=${dbfile/\.*/}
        get_size $dbfile $UNI_DIR_DATA/data_sap $curr_node ""
        dbtotal=`echo "scale=3;$dbtotal+$file_size"|bc`
    done
    dbtotal=`echo "scale=3;$dbtotal/1024"|bc`
    print_metric "ALL_DBFILES_GB" $dbtotal "$curr_node"
}

get_io()
{
	engpid=$1
	rb=`cat /proc/${engpid}/io|grep "read_bytes"|awk '{print $2}'`
	wb=`cat /proc/${engpid}/io|grep "^write_bytes"|awk '{print $2}'`
	rkb=`echo "scale=3;$rb/1024"|bc`
	wkb=`echo "scale=3;$wb/1024"|bc`
	ipinb=`cat /proc/${engpid}/net/netstat|grep "IpExt"|tail ${TAILARG} -1|awk '{print $8}'`
	ipoutb=`cat /proc/${engpid}/net/netstat|grep "IpExt"|tail ${TAILARG} -1|awk '{print $9}'`
	ipikb=`echo "scale=3;$ipinb/1024"|bc`
	ipokb=`echo "scale=3;$ipoutb/1024"|bc`
}

#####################################################################
## INITIALIZATION
#####################################################################
logdebug "Collect metrics on DUAS ($OS) - Debug mode:$DEBUG"
echo "openagent"
echo ""

PATH=$PATH:/usr/local/bin:/usr/bin
# in order to have ps working with standard syntax : (see man 5 standards)
export UNIX_STD=95
IFS="
"
DEBUG=${2:-OFF}
#DEBUG="ON"
# if [ $DEBUG == "ON" ]; then	
	# set -xv
# fi
server=$(hostname)
OS=`uname -s`
NODE=$1
# if [ "$NODE" == "" ]; then
	# log "Usage : `basename $0` <NODE_name>"
	# exit 1
# fi
#AREALIST=( x a i s )
AREALIST=( x )
ENGINELIST=( ioV6 dqmV6 io dqm eep cdj bvs cal ord ech sur sap )
DUAS_STATUS="ON"
instdir=""

PSTOOL=ps
if [ "${OS}" == "Linux" ]; then
	LSOFTOOL=lsof
	LSOFARG=-p
	PSARG="--no-heading"
	TAILARG="-n"
	NETSTATARG1="-tn"
	NETSTATARG2=""
	THREAD_SPECIFIER=nlwp
	READARG=""
elif [ "${OS}" == "SunOS" ]; then
	LSOFTOOL=/usr/local/bin/lsof
	LSOFARG=-p
	PSARG=""
	TAILARG=""
	NETSTATARG1="-n"
	NETSTATARG2=""
	THREAD_SPECIFIER=nlwp
	READARG=""
elif [ "${OS}" == "HP-UX" ]; then
	LSOFTOOL=lsof
	LSOFARG=-p
	PSARG=""
	TAILARG=""
	NETSTATARG1="-n"
	NETSTATARG2="-f inet"
	THREAD_SPECIFIER=nlwp
	READARG=""
elif [ "${OS}" == "AIX" ]; then
	LSOFTOOL=procfiles
	LSOFARG=-c
	PSARG=""
	TAILARG="-n"
	NETSTATARG1="-n"
	#NETSTATARG2="-f inet"
	NETSTATARG2=""
	THREAD_SPECIFIER=thcount
	READARG="read -p"
else
	log "Operating system not supported : ${OS}"
	exit 10
fi

collect_node()
{
    NODE=$1

    repository=/var/opt/ORSYP/.Installer/DUAS
    cd $repository
    soc=`ls|egrep "${NODE}$"`
    cd $soc
    logdebug "DUAS6 : $soc"
    instdir=`grep INSTALLDIR DUAS.installer|cut -f2 -d\|`
    duasversion=6
    logdebug "Installation directory:$instdir"
    if [ "$instdir" == "" ]; then
        log "FATAL : node home dir empty"
        return 1
    fi
    if [ ! -d $instdir ]; then
        log "FATAL: installation directory $instdir does not exist"
        return 3
    fi

    logdebug "Load environment from $instdir/mgr/uxsetenv"
    . $instdir/mgr/uxsetenv >/dev/null

    logdebug "$NODE : dirroot=$UNI_DIR_ROOT, dirdata=$UNI_DIR_DATA, direxe=$UNI_DIR_EXEC, dirlog=$UNI_DIR_LOG"

    #####################################################################
    ## GET PID AND PORTS OF ALL ENGINES
    #####################################################################

    logdebug "ENGINES"
    for ENGINE in ${ENGINELIST[@]}; do
        for AREA in ${AREALIST[@]}; do
            eval ${ENGINE}_${AREA}_pid=0
            eval ${ENGINE}_${AREA}_port=0
            if [ "${ENGINE/@(dqm|eep|uproc)/OK}" == "OK" ] && [ "${AREA}" != "x" ]; then
                continue;
            fi
            if [ $duasversion -eq 6 ]; then
                port=`$UNI_DIR_EXEC/unigetvar U_LST_SRV_PORT | grep -i ${ENGINE}_${AREA}|cut -f2 -d=`
                logdebug "Port for $ENGINE,$AREA=$port"
            else
                port=`grep ${S_SOCIETE}_${ENGINE}_${AREA} /etc/services | awk '{print $2}'|cut -d/ -f1`
            fi
            if [ "$port" != "" ]; then
                eval ${ENGINE}_${AREA}_port=$port
            fi
            get_pid $ENGINE ${AREA} $COMPANY_NAME
            eval ${ENGINE}_${AREA}_pid=$pid
            var=${ENGINE}_${AREA}_pid
            logdebug "PID of $ENGINE,${AREA}=${!var}"
        done
    done

    ################################################################################
    ##
    ## UVMS RESPONSE TIME
    ##
    ################################################################################
    cd $UNI_DIR_EXEC
    ./unims -checkms|& grep -q reachable 2>/dev/null
    if [ $? -eq 0 ]; then
        print_metric "UVMS_REACHABLE" "100" "${NODE}"
        if [ "`uname -s`" != "AIX" ]; then
            resptime_secs=`{ time -p ./unims -checkms; } |& grep real |awk '{print $2}'`
            print_metric "UVMS_SECS_RESPTIME" ${resptime_secs} "${NODE}"
        fi
    else
        print_metric "UVMS_REACHABLE" "0" "${NODE}"
        print_metric "UVMS_SECS_RESPTIME" "-1" "${NODE}"
    fi
    ################################################################################
    jobs_no_duas=0
    if [ "$dqm_x_pid" != "" ]; then
        jobs_no_duas=`ps ${PSARG} -e -o ppid|grep $dqm_x_pid|wc -l|awk '{print $1}'`
    fi
    print_metric "JOBSNO_DUAS" "$jobs_no_duas" "${NODE}"

    ################################################################################
    ##
    ## DISK SIZE
    ##
    ################################################################################
    log_sz=0
    data_sz=0
    bin_sz=0
    duas_sz=0
    varopt_sz=0
    logdebug "DISK ANALYSIS"
    duas_sz=$(du -s -k -H $UNI_DIR_ROOT |awk '{print $1}')
    bin_sz=$(du -s -k -H $UNI_DIR_EXEC |awk '{print $1}')
    mgr_sz=$(du -s -k -H $UNI_DIR_ROOT/mgr |awk '{print $1}')
    let bin_sz=bin_sz+mgr_sz
    log_sz=$(du -s -k -H $UNI_DIR_LOG |awk '{print $1}')
    if [ $duasversion -eq 6 ]; then
        varopt_sz=$(du -s -k -H $repository/`basename $UNI_DIR_ROOT` |awk '{print $1}')
        data_sz=$(du -s -k -H $UNI_DIR_DATA |awk '{print $1}')
    else
        let data_sz=duas_sz-bin_sz-log_sz
    fi

    let duas_sz=${duas_sz}+${varopt_sz}

    if [ "$UXEXE" != "$UNI_DIR_ROOT/bin" ] && [ "$UXEXE" != "$UNI_DIR_ROOT/exec" ]; then
        let duas_sz=duas_sz+bin_sz
    fi
    if [ "$UNI_DIR_DATA" != "$UNI_DIR_ROOT/data" ] && [ "$UNI_DIR_DATA" != "$UNI_DIR_ROOT/exp/data" ]; then
        let duas_sz=duas_sz+data_sz
    fi

    if [ "$UNI_DIR_LOG" != "$UNI_DIR_ROOT/log" ] && [ "$UNI_DIR_DATA" != "$UNI_DIR_ROOT/exp/log" ]; then
        let duas_sz=duas_sz+log_sz
    fi

    # Convert values from kilobytes to Megabytes
    let duas_sz=duas_sz/1024
    let data_sz=data_sz/1024
    let bin_sz=bin_sz/1024
    let log_sz=log_sz/1024

    print_metric "DUAS_DISKSIZE" "$duas_sz" "${NODE}"
    print_metric "DUAS_BIN_DISKSIZE" "$bin_sz" "${NODE}"
    print_metric "DUAS_DATA_DISKSIZE" "$data_sz" "${NODE}"
    print_metric "DUAS_LOG_DISKSIZE" "$log_sz" "${NODE}"
    ################################################################################
    ##
    ## CONNECTIONS
    ## ################################################################################
    cnx_all_duas=0
    for ENGINE in ${ENGINELIST[@]}; do
        for AREA in ${AREALIST[@]}; do
            if [ "${ENGINE/@(dqm|eep)/OK}" == "OK" ] && [ "${AREA}" != "x" ]; then
                continue;
            fi
            var=${ENGINE}_${AREA}_port
            port=${!var}
            if [ $port -ne 0 ]; then
                logdebug "netstat ${NETSTATARG1} ${NETSTATARG2}|tail ${TAILARG} +3|grep $port|grep ESTABLISHED|wc -l|awk '{print $1}'"
                eval cnx_${ENGINE}_${AREA}_duas=`netstat ${NETSTATARG1} ${NETSTATARG2}|tail ${TAILARG} +3|grep $port|grep ESTABLISHED|wc -l|awk '{print $1}'`
            else
                eval cnx_${ENGINE}_${AREA}_duas=0
            fi
            var=cnx_${ENGINE}_${AREA}_duas
            let cnx_all_duas=${cnx_all_duas}+${!var}
        done
    done

    for ENGINE in ${ENGINELIST[@]}; do
        for AREA in ${AREALIST[@]}; do
            if [ "${ENGINE/@(dqm|eep)/OK}" == "OK" ] && [ "${AREA}" != "x" ]; then
                continue;
            fi
            varp=${ENGINE}_${AREA}_pid
            var=cnx_${ENGINE}_${AREA}_duas
            pid=${!varp}
            if [ $pid -eq 0 ] && [ ${!var} -eq 0 ]; then
                continue
            fi
            tmp="${ENGINE}_${AREA}"
            name=`echo "$tmp"|tr '[:lower:]' '[:upper:]'`
            print_metric "CNX" "${!var}" "${NODE}_$name"
        done
    done
    print_metric "CNX_ALL_DUAS" "$cnx_all_duas" "${NODE}"

    ################################################################################
    ##
    ## I/O
    ## ################################################################################
    if [ "${OS}" == "Linux" ]; then
        iorkb_all_duas=0
        iowkb_all_duas=0
        ipikb_all_duas=0
        ipokb_all_duas=0
        for ENGINE in ${ENGINELIST[@]}; do
            for AREA in ${AREALIST[@]}; do
                if [ "${ENGINE/@(dqm|eep)/OK}" == "OK" ] && [ "${AREA}" != "x" ]; then
                    continue;
                fi
                var=${ENGINE}_${AREA}_pid
                pid=${!var}
                if [ $pid -ne 0 ]; then
                    logdebug "I/O of $ENGINE,${AREA},$pid:..."
                    get_io $pid
                    eval iorkb_${ENGINE}_${AREA}_duas=$rkb
                    eval iowkb_${ENGINE}_${AREA}_duas=$wkb
                    eval ipikb_${ENGINE}_${AREA}_duas=$ipikb
                    eval ipokb_${ENGINE}_${AREA}_duas=$ipokb
                else
                    logdebug "I/O of $ENGINE,${AREA},$pid:0"
                    eval iorkb_${ENGINE}_${AREA}_duas=0
                    eval iowkb_${ENGINE}_${AREA}_duas=0
                    eval ipikb_${ENGINE}_${AREA}_duas=0
                    eval ipokb_${ENGINE}_${AREA}_duas=0
                fi
                var=iorkb_${ENGINE}_${AREA}_duas
                iorkb_all_duas=`echo "scale=3;${iorkb_all_duas}+${!var}"|bc`
                var=iowkb_${ENGINE}_${AREA}_duas
                iowkb_all_duas=`echo "scale=3;${iowkb_all_duas}+${!var}"|bc`
                var=ipikb_${ENGINE}_${AREA}_duas
                ipikb_all_duas=`echo "scale=3;${ipikb_all_duas}+${!var}"|bc`
                var=ipokb_${ENGINE}_${AREA}_duas
                ipokb_all_duas=`echo "scale=3;${ipokb_all_duas}+${!var}"|bc`
            done
        done

        for ENGINE in ${ENGINELIST[@]}; do
            for AREA in ${AREALIST[@]}; do
                if [ "${ENGINE/@(dqm|eep)/OK}" == "OK" ] && [ "${AREA}" != "x" ]; then
                    continue;
                fi
                var=${ENGINE}_${AREA}_pid
                pid=${!var}
                if [ $pid -eq 0 ]; then
                    continue
                fi
                
                tmp="${ENGINE}_${AREA}"
                name=`echo "$tmp"|tr '[:lower:]' '[:upper:]'`
                var=iorkb_${ENGINE}_${AREA}_duas
                print_metric "IO_READ_KBPS" "${!var}" "$name"
                tmp="${ENGINE}_${AREA}"
                name=`echo "$tmp"|tr '[:lower:]' '[:upper:]'`
                var=iowkb_${ENGINE}_${AREA}_duas
                print_metric "IO_WRITE_KBPS" "${!var}" "${NODE}_$name"
                tmp="${ENGINE}_${AREA}"
                name=`echo "$tmp"|tr '[:lower:]' '[:upper:]'`
                var=ipikb_${ENGINE}_${AREA}_duas
                print_metric "IP_IN_KBPS" "${!var}" "${NODE}_$name"
                tmp="${ENGINE}_${AREA}"
                name=`echo "$tmp"|tr '[:lower:]' '[:upper:]'`
                var=ipokb_${ENGINE}_${AREA}_duas
                print_metric "IP_OUT_KBPS" "${!var}" "${NODE}_$name"
            done
        done
        print_metric "IO_READ_KBPS_ALL_DUAS" "$iorkb_all_duas" "${NODE}"
        print_metric "IO_WRITE_KBPS_ALL_DUAS" "$iowkb_all_duas" "${NODE}"
        print_metric "IP_IN_KBPS_ALL_DUAS" "$ipikb_all_duas" "${NODE}"
        print_metric "IP_OUT_KBPS_ALL_DUAS" "$ipokb_all_duas" "${NODE}"
    fi

    today=`date +"%Y%m%d"`
    currdayhour=`date +"%Y%m%d%H"`
    currhour=`date +"%H"`
    if [ ! -f /tmp/du6purgereorg_${NODE}_$today ] && [ $currhour -ge 1 ] && [ $duasversion -eq 6 ]; then
        rm -f /tmp/du6purgereorg_${NODE}_*
        touch /tmp/du6purgereorg_${NODE}_$today
        logdebug "get_PurgeReorg $NODE"
        get_purgereorg $NODE
    fi

    if [ ! -f /tmp/du6objects_${NODE}_$currdayhour ]; then
        if [ ${io_x_pid} -gt 0 ]; then
            rm -f /tmp/du6objects_${NODE}_*
            touch /tmp/du6objects_${NODE}_$currdayhour
            logdebug "get_Objects 1 (do collect) $NODE"
            get_objects 1 $NODE
        # else
            # logdebug "get_Objects 0 (IO OFF - do not collect: set all counters to n/a)"
            # get_objects 0
        fi
        logdebug "get_DataSize $NODE"
        get_datasize $NODE
    # else
        # logdebug "get_Objects 0 (do not collect: set all counters to n/a)"
        # get_objects 0
    fi
    
    return 0
}

#####################################################################
## MAIN
##
#####################################################################
repository=/var/opt/ORSYP/.Installer/DUAS/
socdir=/SocieteQualif/$NODE
logdebug "Looking for $socdir and $socdir/exec/uxversion..."
if [ -d $socdir ] && [ -f $socdir/exec/uxversion ]; then
        logdebug "DUAS5 : $socdir"
        instdir=$socdir
        duasversion=5
        logdebug "DUAS v5x not supported"
        exit 20
elif [ -d $repository ]; then
    if [ "$NODE" != "" ]; then
        collect_node $NODE
        ret=$?
    else
        ret=0
        for soc in $(find $repository -maxdepth 1 -type d)
        do
            if [ "$soc" == "." ] || [ "$soc" == "$repository" ]; then
                continue
            fi
            collect_node $(basename $soc)
            retn=$?
            ret=$((ret && retn))
        done
    fi
else
    log "DUAS not installed ($repository not found)"
fi

exit $ret