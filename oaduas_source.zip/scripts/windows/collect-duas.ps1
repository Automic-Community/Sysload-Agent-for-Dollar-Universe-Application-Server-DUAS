# Collect specific metrics on Dollar Universe Application Server
# by CHM - SA - Automic

param (
    [string]$NODE="",
# Set this to enable debug mode : 
	[switch]$d,
	[switch]$help
)

#####################################################################
## FUNCTIONS
#####################################################################
function usage()
{
    "Collect specific metrics on Dollar Universe Application Server"
    "./collect-duas.ps1 -NODE <node> [-d (debug mode)] [-help]"
	" "
	"Prerequisite : Powershell v2 or higher"
	exit(2)
}

# Logging function
function log()
{
	param($msg,$level=0)
	if($level -le $loglevel)
	{
		$now=get-date -format g
		Write-Output $now" "$currscript": "$msg | out-file -filepath $log_file -append 
        #-Encoding "ASCII"
	}
	if ( $DEBUG -eq "ON" )
	{
		Write-Host $msg
	}
}

function logdebug()
{
	param($message, $reset = 0)
    $date_formated = (get-date).tostring('yyyy MM dd HH mm ss')
	
    $logmsg = "{0} {1}" -f $date_formated, $message
    # Note: No verification if OK
	
	if($reset -eq 1)
	{
		# Reset the file back to null size first
		$logmsg | Out-File $log_file
	}
	else
	{
		# Add message to the end of the file
		$logmsg | Out-File $log_file -Append
	}
	if($DEBUG -eq "ON")
	{
		Write-Host $message
	}
}

function print-metric() 
{
	param ($name, $instance, $value)
	Write-output ${name}"#"${instance}"##"${value}
	log ${name}"#"${instance}"##"${value}
}

function get_pid()
{
	param($name,$area,$soc)
	switch ($name)
	{
		"ioV6"  { $process="uniservio_V6" }
		"dqmV6" { $process="uniservdqm_V6" }
		"io"    { $process="uniservio" }
		"dqm"   { $process="uniservdqm" }
		"cdj"   { $process="uniservcdj" }
		"bvs"   { $process="uniservbvs" }
		"eep"   { $process="uniserveep" }
		"cal"   { $process="unical" }
		"ord"   { $process="uniord" }
		"ech"   { $process="uniech" }
		"sur"   { $process="unisur" }
		default { return 0 }
	}
	logdebug "Searching process $process $soc $area $NODE"
	$allproc=get-wmiobject "Win32_process" |where {$_.Name -match ${process}}
	foreach ($proc in $allproc)
	{
		$msg=$proc.CommandLine+", "+$proc.ProcessID
		log $msg 1
	
#		if ( $proc.CommandLine -match "$soc" -and $proc.CommandLine -match "$area" -and $proc.CommandLine -match "$NODE" )
		if ( $proc.CommandLine -match "$soc" -and $proc.CommandLine -match "$NODE" )
		{
			$currpid=$proc.ProcessID
		}
	}
	if ( "$currpid" -eq "" )
	{
		$currpid=0
	}
	logdebug "[get_pid] PID of $process $COMPANY_NAME $area $NODE=$currpid"
	$currpid
}

function DiskUsage()
{
	param($inputdir=".")
	logdebug "Disk Usage $inputdir"
	$results = @()
	$dirs = Get-ChildItem -Recurse $inputdir | Where-Object {$_.PSIsContainer}
	foreach ($dir in $dirs) 
	{
		$files =  Get-ChildItem $dir.pspath 
		$total = 0
		foreach ($file in $files) 
		{
			$total += $file.Length
		}
		$results += New-Object psobject -Property @{Folder=$dir.fullname;Size=$total}
	}
	$results | Sort-Object -Property Folder | Format-Table -AutoSize
	#$biggestFolder = ($results | Sort-Object -Property Size -Descending)[0] -replace '[@\{\}]'
	#Write-Host "Biggest $biggestFolder" 
}

function diff_times()
{
	param($start_time,$end_time)
    # logdebug "diff_time $start-time -> $end_time"
	$diff=0
	$H1=(${start_time} -split ":")[1]
	$M1=(${start_time} -split ":")[2]
	$S1=(${start_time} -split ":")[3]
	$H2=(${end_time} -split ":")[1]
	$M2=(${end_time} -split ":")[2]
	$S2=(${end_time} -split ":")[3]
	$hms1=[int]$H1*3600+[int]$M1*60+[int]$S1
	$hms2=[int]$H2*3600+[int]$M2*60+[int]$S2
	if ( $hms1 -gt $hms2 ) 
	{
		$hms2=[int]$hms2+86400
	}
	$diff=$hms2-$hms1
	logdebug "diff_times $start_time > $end_time = $diff"
	$diff
}

function get_timestamp()
{
	param($to_search)
    if($global:UNIVERSE_LOG -eq $null)
    {
        $global:UNIVERSE_LOG=get-content ${UNI_DIR_LOG}\universe*.log|select-string 'X'|select-string $todaylog
    }
	logdebug "((get-content ${UNI_DIR_LOG}\universe*.log | select-string `"$to_search`"  | select-string 'X'|select-string $todaylog) -split `" +`")[2]"
	$timestamp=(($global:UNIVERSE_LOG | select-string "$to_search") -split " +")[2]
	logdebug "get_timestamp $to_search = <$timestamp>"
	$timestamp
}

function get_resptime()
{
	param($dbfile,$t0,[string]$current_instance)
	$diff=0
	$t1=get_timestamp "$dbfile reorganization successful"
	$diff=diff_times $t0 $t1
	log "$dbfile reorganized in (secs) : $diff"
	print-metric "DB_REORG_RESPTIME_SECS" "${current_instance}_${dbfile}" "$diff"
	$t0=$t1
	$t0
	$diff
}

function get_size()
{
	param($dbfile,$datadir,[string]$current_instance)
	#log "$dbfile ... "
	$total= (get-childitem $datadir\${dbfile}* | measure-object -property length -sum).sum
	# Format number with local regional settings (for decimal point)
    # $total="{0:N3}" -f ($total/(1024*1024))
    # Below format number with decimal point forced to dot '.'
    $total= "{0:0'.'000}" -f ($total/(1024*1024))
	log "$dbfile : $total kb ($datadir)"
	Write-Output "SIZE_MB#${current_instance}_${dbfile}##$total"
}

#====================================================================
# Call a DOS script then capture all environment variables set
# and set them to make them available for powershell script
function Invoke-CmdScript()
{
	param([string] $script, [string] $parameters) 

	$tempFile = [IO.Path]::GetTempFileName() 

	## Store the output of cmd.exe.  We also ask cmd.exe to output  
	## the environment table after the batch file completes 

	cmd /c " `"$script`" $parameters && set > `"$tempFile`" "

	## Go through the environment variables in the temp file. 
	## For each of them, set the variable in our local environment. 
	Foreach ( $currline in (Get-Content $tempFile) )
	{  
		if($currline -match "^(.*?)=(.*)$") 
		{
			Set-Content "env:\$($matches[1])" $matches[2] 
		}
	} 

	Remove-Item $tempFile 
}

###############################################################################
###############################################################################
function get_Objects()
{
	param ($DO_COLLECT,[string]$current_instance)
	function count_obj()
	{
		param($obj,$arg,[string]$current_instance)
		log "$obj ... "
		if ( ${DO_COLLECT} -gt 0 )
		{
			if ( "$arg" -ne "" )
			{
				$nb=(& ${UNI_DIR_EXEC}\uxlst.exe $obj $arg | measure-object -line).lines
			}
			else
			{
				$nb=(& ${UNI_DIR_EXEC}\uxlst.exe $obj | measure-object -line).lines
			}
			$nb=$nb-4
		}
		else
		{
			$nb=-1
		}

		log "$nb"
		print-metric "OBJECTS" "${current_instance}_${obj}" "$nb"

		if ( $nb -lt 0 )
		{
			$nb=0
		}
		$total=$total+$nb
	}

	count_obj res "" ${current_instance}
	count_obj class "" ${current_instance}
	count_obj dom "" ${current_instance}
	count_obj appl "" ${current_instance}
	count_obj rul "" ${current_instance}
	count_obj upr "" ${current_instance}
	count_obj ses "" ${current_instance}
	count_obj tsk "" ${current_instance}
	count_obj book "" ${current_instance}
	count_obj note "" ${current_instance}
	count_obj node "" ${current_instance}
	count_obj user "" ${current_instance}
	count_obj mu "" ${current_instance}
	count_obj mut "" ${current_instance}
	count_obj cal "" ${current_instance}
	log "que ... "
	if ( ${DO_COLLECT} -gt 0 )
	{
		if ( test-path $UNI_DIR_EXEC\uxlstque.exe )
		{
			$nb=(& $UNI_DIR_EXEC\uxlstque.exe | measure-object -line).lines
			$nb=$nb-4
		}
		else
		{
			$nb=-1
		}
	}
	else
	{
		$nb=-1
	}
	log "$nb"
	print-metric "OBJECTS" "${current_instance}_queue" "$nb"
	$total=$total+$nb
	if ( $total -lt 0 )
	{
		$total=-1
	}
	log "Total number of design objects: $total"
	print-metric "ALL_DESIGN_OBJECTS" "${current_instance}" "$total"

	if ( test-path ${UNI_DIR_TEMP}\du6since_${current_instance} )
	{
		$now=get-content ${UNI_DIR_TEMP}\du6since_${current_instance}
	}
	else
	{
		$now="00/00/0000,0000"
		#now=date +%m/%d/%Y,%H%M
	}	

	count_obj fla "" ${current_instance}
	# count_obj ctl "since=($now) status=O,R,T,A" ${current_instance}
	# count_obj hcx "since=($now)" ${current_instance}
	if ( ${DO_COLLECT} -eq 1 )
	{
		get-date -format "MM/dd/yyyy,hhmm" > ${UNI_DIR_TEMP}\du6since_${current_instance}
	}
	# count_obj evt "" ${current_instance}
	count_obj sta "" ${current_instance}
	count_obj oex "" ${current_instance}
	count_obj out "" ${current_instance}

	#today=date +"%Y%m%d"
	#currhour=date +"%H"
	#if ( ! test-path /tmp/du6countctlhst_$today ] && [ $currhour -ge 1 )
	#{
	#	rm -f /tmp/du6countctlhst_*
	#	touch /tmp/du6countctlhst_$today
	#	count_obj "hcx"
	#}
	if ( $total -lt 0 )
	{
		$total=-1
	}

	log "Total number of objects: $total"
	print-metric "ALL_OBJECTS" "${current_instance}" "$total"
}

###############################################################################
###############################################################################
function get_DataSize()
{
    param([string]$current_instance)
	logdebug "DATA DB SIZE"
	if ( test-path ${UNI_DIR_ROOT}\data\exp ) 
	{
		$UXDEX="${UNI_DIR_ROOT}\data\exp"
	}
	else
	{
		$UXDEX="$UNI_DIR_ROOT\exp\data"
	}
	$dbtotal=0
	foreach ( $dta in get-childitem $UXDEX\u_*.dta  )
	{
		$dbfile=split-path -Leaf $dta
		$dbfile=(${dbfile} -split "\." )[0]
		logdebug "$dta => $dbfile"
		$ret=get_size $dbfile $UXDEX ${current_instance}
		$ret
		$dbtotal += ($ret -split "#")[3]
	}
	foreach ( $dta in get-childitem $UXDEX\*.db  )
	{
		$dbfile=split-path -Leaf $dta
		$dbfile=(${dbfile} -split "\." )[0]
		logdebug "$dta => $dbfile"
		$ret=(get_size ${dbfile}_EXP $UXDEX ${current_instance})
		$ret
		$dbtotal += ($ret -split "#")[3]
	}

	foreach ( $dta in get-childitem ${UNI_DIR_DATA}\u_*.dta )
	{
		$dbfile=split-path -Leaf $dta
		$dbfile=(${dbfile} -split "\." )[0]
		logdebug "$dta => $dbfile"
		$ret=(get_size $dbfile $UNI_DIR_DATA ${current_instance})
		$ret
		$dbtotal += ($ret -split "#")[3]
	}
	foreach ( $dta in get-childitem ${UNI_DIR_DATA}\*.db )
	{
		$dbfile=split-path -Leaf $dta
		$dbfile=(${dbfile} -split "\." )[0]
		logdebug "$dta => $dbfile"
		$ret=(get_size $dbfile $UNI_DIR_DATA ${current_instance})
		$ret
		$dbtotal += ($ret -split "#")[3]
	}
	$dbtotal=$dbtotal/(1024*1024)
	print-metric "ALL_DBFILES_GB" "${current_instance}" "$dbtotal" 
}

###############################################################################
## PURGE AND REORGANIZATION RESPONS TIMES (get from universe.log file and archives)
###############################################################################
function get_PurgeReorg()
{
    param([string]$current_instance)
	# For a V5 node - example of complete line : 
	# 2013-02-27 00:03:17 0006410/uxioserv        /io_purge            /000000000 - IO [X] online purge start
	# << 2013-02-27 00:04:10 0006410/uxioserv        /io_purge            /000000000 - IO [X] online purge end

	# For a V6 node - pattern to search for : 
	# ##### START OF IO PURGE #####
	# ##### END OF IO PURGE #####

    # initialize a global variable to store content of universe.log in memory
    # for better performance
    $global:UNIVERSE_LOG=$null
    
	$res=get_timestamp "##### START OF IO PURGE #####"
	$purt0=$res
	if ( "$purt0" -eq "" -or $purt0 -le 0 ) 
	{
		# Considering this is a V5 node : 
		$res=get_timestamp "online purge start"
		$purt0=$res
		$res=get_timestamp "online purge end"
		$purt1=$res
	}
	else
	{
		# This is a V6 node : 
		$res=get_timestamp "##### END OF IO PURGE #####"
		$purt1=$res
	}

	logdebug "Purge start time:$purt0"
	logdebug "Purge end time:$purt1"

	$res=diff_times $purt0 $purt1

	log "Response time of purge (secs) : $res"
	print-metric "PURGE_RESPTIME_SECS" "${current_instance}" "$res"

	$reorgt0=$purt1
	logdebug "Reorg start time:$reorgt0"

	$res=get_timestamp "End of reorg for area X"
	$reorgt1=$res
	if ( "$reorgt1" -eq "" ) 
	{
		$reorgt0=""
	}
	logdebug "Reorg end time:$reorgt1"
	$res=diff_times $reorgt0 $reorgt1
	log "Response time of reorg (secs) : $res"
	print-metric "REORG_RESPTIME_SECS" "${current_instance}" "$res"

	$t0=$reorgt0
	$res=get_resptime u_fecd60 $t0
	$t0=$res[0]
	
	if ( $res[1] -ne "" -and $res[1] -gt 0 ) 
	{
		logdebug "res1=<"+$res[1]+">"
	
		$res=get_resptime u_fecl60 $res[0] ${current_instance}
		$res=get_resptime u_fmca60 $res[0] ${current_instance}
		$res=get_resptime u_fmcm60 $res[0] ${current_instance}
		$res=get_resptime u_fmcx60 $res[0] ${current_instance}
		$res=get_resptime u_fmer60 $res[0] ${current_instance}
		$res=get_resptime u_fmev60 $res[0] ${current_instance}
		$res=get_resptime u_fmfu60 $res[0] ${current_instance}
		$res=get_resptime u_fmhs60 $res[0] ${current_instance}
		$res=get_resptime u_fmlc60 $res[0] ${current_instance}
		$res=get_resptime u_fmlp60 $res[0] ${current_instance}
		$res=get_resptime u_fmpf60 $res[0] ${current_instance}
		$res=get_resptime u_fmph60 $res[0] ${current_instance}
		$res=get_resptime u_fmpi60 $res[0] ${current_instance}
		$res=get_resptime u_fmpl60 $res[0] ${current_instance}
		$res=get_resptime u_fmsb60 $res[0] ${current_instance}
		$res=get_resptime u_fmse60 $res[0] ${current_instance}
		$res=get_resptime u_fmsp60 $res[0] ${current_instance}
		$res=get_resptime u_fmta60 $res[0] ${current_instance}
		$res=get_resptime u_fmtp60 $res[0] ${current_instance}
		$res=get_resptime u_fmtr60 $res[0] ${current_instance}
		$res=get_resptime u_fppf60 $res[0] ${current_instance}
		$res=get_resptime u_frup60 $res[0] ${current_instance}
		$res=get_resptime u_fseu60 $res[0] ${current_instance}
		$res=get_resptime u_fupr60 $res[0] ${current_instance}
		$res=get_resptime u_fbvi60 $res[0] ${current_instance}
		$res=get_resptime u_fbvm60 $res[0] ${current_instance}
		$res=get_resptime u_frrv60 $res[0] ${current_instance}
		$res=get_resptime u_fmat60 $res[0] ${current_instance}
		$res=get_resptime u_fmhr60 $res[0] ${current_instance}
		$res=get_resptime u_fmoe60 $res[0] ${current_instance}
		$res=get_resptime u_fmrn60 $res[0] ${current_instance}
		$res=get_resptime dffdob60 $res[0] ${current_instance}
		$res=get_resptime u_fmeq60 $res[0] ${current_instance}
		$res=get_resptime u_fmqp60 $res[0] ${current_instance}
		$res=get_resptime u_fmqr60 $res[0] ${current_instance}
		$res=get_resptime u_fmrl60 $res[0] ${current_instance}
	}
	else
	{
		logdebug "no reorganization found in log"
	}
}

#####################################################################
## VARIABLES
#####################################################################
#set-psdebug -trace 1
# Store start time
$timer_start = get-date

# Settings for file paths
$home_directory = $PSScriptRoot
$log_file = "{0}\script.log" -f $home_directory
if ( test-path $log_file ) { remove-item -force $log_file }
$loglevel=1

$currdir = split-path -path ($MyInvocation.MyCommand.Definition)
$currscript=$MyInvocation.MyCommand.Definition
Set-Location $currdir

$script_name = $MyInvocation.MyCommand.Name
$script_version = "2.1"
$script_date = "mar 2016"

$message = "---------------------------------------------------------------------------------------"
logdebug -message $message -reset $true
$message = "Script '{0}', Version '{1}', date '{2}'" -f $script_name, $script_version, $script_date
log $message
if ($help -eq $True)
{
	usage
	exit(2)
}

logdebug "Start Sysload collector for Dollar Universe Application Server"
# Check arguments
if($d)
{
    $DEBUG="ON"
}
else
{ 
    $DEBUG="OFF" 
}

$QAROOTDIR = get-location
# Variables initialization based on QA standards :
$server = hostname

# Registry key for installed DUAS nodes (not used here):
#HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\ORSYP S.A.\Dollar Universe\Instance_COMPANY NODENAME   

$io_path_list=(Get-WmiObject -query "SELECT PathName FROM Win32_Service WHERE Name like '%_IO_X'").PathName
# example of feedback : "C:\SocieteQualif\DUAS\BCHSAP_vmstmbch001\bin\UniServIO.exe"
foreach($io in $io_path_list)
{
    $socdir=split-path(split-path ($io -replace '"',''))
    if (-not (test-path $socdir))
    {
        log "Installation dir of $io not found"
        exit 2
    }
    $INSTANCE=split-path -leaf $socdir
    if($NODE -ne "" -and $NODE -ne $INSTANCE)
    {
        logdebug "Skip $INSTANCE (<>$NODE)"
        continue
    }
    logdebug "Collect DUAS ${INSTANCE} in ${socdir}, server=${server} (debug=${DEBUG})"

    Invoke-CmdScript -script "$socdir\unienv.bat" -parameters "" >$null
    if ( (get-childitem env:UNI_DIR_ROOT*) )
    {
        logdebug "v6 node (uni_dir_root=${env:UNI_DIR_ROOT})"
        $UNI_DIR_ROOT=${env:UNI_DIR_ROOT}
        $UNI_DIR_EXEC=${env:UNI_DIR_EXEC}
        $UNI_DIR_LOG=${env:UNI_DIR_LOG}
        $UNI_DIR_DATA=& ${UNI_DIR_EXEC}\unigetvar.exe UNI_DIR_DATA
        $UNI_DIR_TEMP=${currdir}
        $duasversion=6
    }
    else {
        if (${env:UXDIR_ROOT} -ne "" )
        {
            logdebug "v5 node"
            $UNI_DIR_ROOT=${env:UXDIR_ROOT}
            $UNI_DIR_EXEC=${env:UXEXE}
            $UNI_DIR_LOG=${env:UXLOG}
            $UNI_DIR_DATA=${env:UXDEX}
            $UNI_DIR_TEMP=${currdir}
            $duasversion=5
        }
        else
        {
            write-error "DUAS environment failed to load"
            log "ERROR : DUAS environment failed to load"
            exit 1
        }
    }
    $COMPANY_NAME=${env:COMPANY_NAME}
    $S_NODENAME=${env:S_NODENAME}
    logdebug "dirroot=$UNI_DIR_ROOT, dirdata=$UNI_DIR_DATA, direxe=$UNI_DIR_EXEC"
    logdebug "dirlog=$UNI_DIR_LOG, dirtemp=$UNI_DIR_TEMP"
    logdebug "Company $COMPANY_NAME, Node : $S_NODENAME"

    $AREALIST=@("X")
    $ENGINELIST=@("IOV6", "DQMV6", "IO", "DQM", "EEP", "CDJ", "BVS", "CAL", "ORD", "ECH", "SUR", "GSI")
    $DUAS_STATUS="ON"
    $today=get-date -format g
    $today2=get-date -format "ddMMyyyy"
    $todaylog=get-date -format "yyyy-MM-dd"
    $currdayhour=get-date -format "ddMMyyyyHH"
    $currhour=get-date -format "HH"
    logdebug "Today : $today=$today2=$todaylog, current day+hour: $currdayhour, current hour: $currhour"

    #####################################################################
    ## INITIALIZATION
    #####################################################################
    logdebug "ENGINES"
    $ii=0
    $UXPID=@()
    $PORT=@()
    foreach ( $ENGINE in ${ENGINELIST} )
    {
        foreach ( $AREA in ${AREALIST} )
        {
            if ( ("${ENGINE}" -eq "dqm" -or "${ENGINE}" -eq "eep") -and "${AREA}" -ne "x" ) 
            {
                continue;
            }
            $UXPID +=0
            $PORT +=0
            if ( $duasversion -eq 6 ) 
            {
                $foundport=((((get-content ${UNI_DIR_DATA}\values.xml | select-string "${ENGINE}_${AREA}" ) -split "=")[1]) -split "<")[0]
                logdebug "Port for $ENGINE,$AREA=$foundport"
            }
            else
            {
                $foundport=(((get-content ${env:WINDIR}\System32\Drivers\etc\services | select-string ${COMPANY_NAME}_${ENGINE}_${AREA} ) -split " ")[1] -split "/")[0]
            }
            if ( "$foundport" -ne "" ) 
            {
                $PORT[$ii]=$foundport
            }
            $foundpid=get_pid $ENGINE ${AREA} $COMPANY_NAME
            if ( $AREA -eq "X" -and $ENGINE -eq "IO" -and $foundpid -eq 0 )
            {
                $DUAS_STATUS="OFF"
                logdebug "No IO/X found : DUAS is $DUAS_STATUS"
            }
            $UXPID[$ii]=$foundpid
            logdebug "PID of $ENGINE,${AREA}=$foundpid"
            $ii++
        }
    }

    ################################################################################
    ##
    ## UVMS RESPONSE TIME
    ##
    ################################################################################
	Write-Output "openagent"
	Write-Output ""
    $res=& $UNI_DIR_EXEC\unims.exe -checkms |select-string "reachable"
    if ( $res.count -gt 0 )
    {
        print-metric "UVMS_REACHABLE" "${INSTANCE}" "100"
        $resptime_secs=(measure-command { & $UNI_DIR_EXEC\unims.exe -checkms; }).Seconds
        print-metric "UVMS_SECS_RESPTIME" "${INSTANCE}" ${resptime_secs}
    }
    else
    {
        print-metric "UVMS_REACHABLE" "${INSTANCE}" "0"
        print-metric "UVMS_SECS_RESPTIME" "${INSTANCE}" "-1"
    }
    ################################################################################
    $jobs_no_duas=(get-wmiobject Win32_Process -filter "CommandLine like '%u_batch%'" | select-object CommandLine|select-string "${INSTANCE}"|select-string 'X'|measure-object -line).lines
    print-metric "JOBSNO_DUAS" "${INSTANCE}" "$jobs_no_duas"

    ################################################################################
    ##
    ## DISK SIZE
    ##
    ################################################################################
    $log_sz=0
    $data_sz=0
    $bin_sz=0
    $duas_sz=0
    $varopt_sz=0
    logdebug "DISK ANALYSIS"
    $duas_sz=(Get-ChildItem -recurse $UNI_DIR_ROOT | Measure-Object -property length -sum).Sum
    $bin_sz=(Get-ChildItem -recurse $UNI_DIR_EXEC | Measure-Object -property length -sum).Sum
    $mgr_sz=(Get-ChildItem -recurse ${UNI_DIR_ROOT}\mgr | Measure-Object -property length -sum).Sum
    $bin_sz=$bin_sz+$mgr_sz
    $log_sz=(Get-ChildItem -recurse $UNI_DIR_LOG | Measure-Object -property length -sum).Sum
    if ( $duasversion -eq 6 ) 
    {
        #$varopt_sz=(Get-ChildItem $repository\${COMPANY_NAME}_${S_NODENAME} | Measure-Object -property length -sum).Sum
        $data_sz=(Get-ChildItem -recurse $UNI_DIR_DATA | Measure-Object -property length -sum).Sum
    }
    else
    {
        $data_sz=$duas_sz-$bin_sz-$log_sz
    }

    $duas_sz=${duas_sz}+${varopt_sz}

    if ( (-not "$UNI_DIR_EXEC" -eq "$UNI_DIR_ROOT\bin") -and (-not "$UNI_DIR_EXEC" -eq "$UNI_DIR_ROOT\exec") ) 
    {
            $duas_sz=$duas_sz+$bin_sz
    }
    if ( (-not "$UNI_DIR_DATA" -eq "$UNI_DIR_ROOT\data") -and (-not "$UNI_DIR_DATA" -eq "$UNI_DIR_ROOT\exp\data") ) 
    {
            $duas_sz=$duas_sz+$data_sz
    }

    if ( (-not "$UNI_DIR_LOG" -eq "$UNI_DIR_ROOT\log") -and (-not "$UNI_DIR_DATA" -eq "$UNI_DIR_ROOT\exp\log" ) )
    {
            $duas_sz=$duas_sz+$log_sz
    }

    # Convert values from bytes to Megabytes
    $duas_sz=$duas_sz/(1024*1024)
    $data_sz=$data_sz/(1024*1024)
    $bin_sz=$bin_sz/(1024*1024)
    $log_sz=$log_sz/(1024*1024)

    print-metric "DUAS_DISKSIZE" "${INSTANCE}" "$duas_sz"
    print-metric "DUAS_BIN_DISKSIZE" "${INSTANCE}" "$bin_sz"
    print-metric "DUAS_DATA_DISKSIZE" "${INSTANCE}" "$data_sz"
    print-metric "DUAS_LOG_DISKSIZE" "${INSTANCE}" "$log_sz"

    ################################################################################
    ##
    ## CONNECTIONS
    ##
    ################################################################################
    logdebug "CONNECTIONS"
    $cnx_all_duas=0
    $ii=0
    $CNX=@()
    foreach ( $ENGINE in ${ENGINELIST} ) 
    {
        foreach ( $AREA in ${AREALIST} ) 
        {
            if ( ("${ENGINE}" -eq "dqm" -or "${ENGINE}" -eq "eep") -and "${AREA}" -ne "x" )
            {
                continue;
            }
            
            $CNX += 0
            
            if ( $PORT[$ii] -ne 0 ) 
            {
                $searchedport=$PORT[$ii]
                logdebug "netstat $searchedport"
                $currcnx= (netstat -an |select-string "$searchedport" | measure-object -line).lines
                $CNX[$ii] = $currcnx
            } 
            else 
            {
                $CNX[$ii]=0
                $currcnx=0
            }
            
            $name="${ENGINE}_${AREA}" # doit etre en majuscules
            print-metric "CNX" ${INSTANCE}_$name "$currcnx"
            $cnx_all+=$cnx
            $ii++
        }
    }

    print-metric "CNX_ALL_DUAS" "$INSTANCE" "$cnx_all_duas"

    logdebug "Testing path ${UNI_DIR_TEMP}\du6purgereorg_${INSTANCE}_${today2} ..."
    if ( -not (test-path ${UNI_DIR_TEMP}\du6purgereorg_${INSTANCE}_${today2}) -and $currhour -ge 1 -and $duasversion -eq 6 ) 
    {
        remove-item -force ${UNI_DIR_TEMP}\du6purgereorg_${INSTANCE}_*
        $res=new-item -type file ${UNI_DIR_TEMP}\du6purgereorg_${INSTANCE}_${today2}
        logdebug "get_PurgeReorg"
        get_PurgeReorg ${INSTANCE}
    }
    else
    {
        logdebug "Not time to get purge/reorg metrics"
    }

    if ( $DUAS_STATUS -eq "ON" -and (-not (test-path $UNI_DIR_TEMP\du6objects_${INSTANCE}_$currdayhour)) ) 
    {
        remove-item -force $UNI_DIR_TEMP\du6objects_${INSTANCE}_*
        $res=new-item -type file ${UNI_DIR_TEMP}\du6objects_${INSTANCE}_${currdayhour}
        logdebug "get_Objects 1 (do collect)"
        get_Objects 1 ${INSTANCE}
    }
    # else 
    # {
        # logdebug "get_Objects 0 (do not collect: set all counters to n/a), duas status=$DUAS_STATUS"
        # get_Objects 0 ${INSTANCE}
    # }

    logdebug "get_DataSize"
    get_DataSize ${INSTANCE}
}

################################################################################
# Store stop time
$timer_stop = get-date

$duration_total = $timer_stop - $timer_start
$duration_ms = [string]($duration_total.totalseconds*1000)
$message = "Total Work duration = '{0}' ms" -f $duration_ms
log $message 
	
log "End" 
exit(0)